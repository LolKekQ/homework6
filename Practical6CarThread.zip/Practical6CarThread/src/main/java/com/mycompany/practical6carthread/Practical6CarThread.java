/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package com.mycompany.practical6carthread;

import java.io.File;
import java.util.Scanner;

/**
 *
 * @author М_З_А
 */
public class Practical6CarThread {

    public static void main(String[] args) {
        System.out.println("Практическая работа №6, вариант 1, Пашин А.М., РИБО-01-21");
        
        String mark, col;
        int pr, cp, ms;
        
        System.out.println("Введите марку автомобиля:");
        mark = scan();
        System.out.println("Введите цвет автомобиля:");
        col = scan();
        System.out.println("Введите цену автомобиля (руб):");
        pr = Integer.parseInt(scan());
        System.out.println("Введите вместимость автомобиля (чел):");
        cp = Integer.parseInt(scan());
        System.out.println("Введите максимальную скорость автомобиля (в км/ч):");
        ms = Integer.parseInt(scan());
        
        Car plant = new Car(mark,col,pr,cp,ms);
    
    File file = new File("C:\\Pashin\\FinObj.txt");
        SaverRunnable saver = new SaverRunnable(plant, "C:\\Pashin\\FinObj.txt");
        Thread thread = new Thread(saver);
        thread.start();
        System.out.println("Ваша машина была сохранена в: " + file);
    }

    public static String scan() {
        return new Scanner(System.in).nextLine();
    }
}

