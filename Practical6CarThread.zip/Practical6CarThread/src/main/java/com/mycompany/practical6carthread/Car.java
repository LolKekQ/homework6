/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.practical6carthread;

import java.io.Externalizable;
import java.io.IOException;
import java.io.ObjectInput;
import java.io.ObjectOutput;

/**
 *
 * @author М_З_А
 */
public class Car implements Externalizable{
    private String marka;
    private String color;
    private int price;
    private int capacity;
    private int maxspeed;

    public Car(String marka, String color, int price, int capacity, int maxspeed) {
        this.marka = marka;
        this.color = color;
        this.price = price;
        this.capacity = capacity;
        this.maxspeed = maxspeed;
    }

    public String getMarka() {
        return marka;
    }

    public void setMarka(String marka) {
        this.marka = marka;
    }

    public String getColor() {
        return color;
    }

    public void setColor(String color) {
        this.color = color;
    }

    public int getPrice() {
        return price;
    }

    public void setPrice(int price) {
        this.price = price;
    }

    public int getCapacity() {
        return capacity;
    }

    public void setCapacity(int capacity) {
        this.capacity = capacity;
    }

    public int getMaxspeed() {
        return maxspeed;
    }

    public void setMaxspeed(int maxspeed) {
        this.maxspeed = maxspeed;
    }

    

    public Car() {}

    @Override
    public void writeExternal(ObjectOutput out) throws IOException {
        out.writeObject(this.getMarka());
        out.writeObject(this.getColor());
        out.writeObject(this.getPrice());
        out.writeObject(this.getCapacity());
        out.writeObject(this.getMaxspeed());
    }

    @Override
    public void readExternal(ObjectInput in) throws IOException, ClassNotFoundException {
        this.marka = (String)in.readObject();
        this.color = (String)in.readObject();
        this.price = (Integer)in.readObject();
        this.capacity = (Integer)in.readObject();
        this.maxspeed = (Integer)in.readObject();
    }

    @Override
    public String toString(){
    return "Марка: " + getMarka() + ", цвет: " + getColor() + ", цена (руб): " + getPrice() + ", вместимость (чел): " + getCapacity() + ", маквсимальная скорость (в км/ч): " + getMaxspeed();
    }
}
